# Notas de integración FCM — fixed11 revisión

## Cambios incluidos
- Firebase Messaging Android y servicio receptor `CredixcelMessagingService`.
- Obtención y registro del token FCM asociado al dispositivo enrolado.
- Firma HMAC-SHA256 de órdenes `LOCK` / `UNLOCK` usando el token de dispositivo autenticado, con ventana de vigencia y protección local contra repetición.
- Tabla SQLite `device_orders` y columna `devices.fcm_token`, agregadas mediante migración no destructiva.
- Confirmación autenticada de órdenes desde el dispositivo.
- Panel con consulta de las últimas órdenes por dispositivo.
- Corrección de `releaseKiosk()`: `protectionActive` no se desactiva si falla detener Lock Task, limpiar HOME o liberar políticas; se intenta restaurar la protección ante una liberación parcial.

## Configuración requerida en Render
Agregar la variable privada `FIREBASE_SERVICE_ACCOUNT_JSON` con el contenido JSON de una cuenta de servicio de Firebase Admin SDK del proyecto `credixcel-control`. No usar `google-services.json` como credencial del servidor: son archivos y credenciales con propósitos distintos.

También deben estar configuradas `ADMIN_SECRET` y `ADMIN_PASSWORD` con valores aleatorios fuertes. Los valores de respaldo del código no son adecuados para producción.

Después de desplegar el servidor, verificar `/health`, iniciar sesión en el panel, enrolar/sincronizar un equipo y confirmar que el token FCM queda registrado. El dispositivo necesita conectividad y Google Play services compatibles.

## Límites que requieren prueba en dispositivo real
- FCM es un canal de entrega de mejor esfuerzo; el servidor conserva el estado y la sincronización manual sigue siendo el respaldo.
- Una respuesta de envío FCM `SENT` solo confirma que Firebase aceptó el mensaje, no que Android ejecutó la orden.
- La confirmación `COMPLETED` / `FAILED` se registra por separado. La salida visual de Lock Task al recibir `UNLOCK` debe verificarse en el modelo Android real; el servicio reporta `ACTIVITY_EXIT_UNVERIFIED` si no puede asegurarla.
- No se generó ni firmó un APK en este entorno. Se requiere compilar con GitHub Actions y probar bloqueo, reinicio, liberación y recuperación en el equipo de pruebas.
- La versión de respaldo 1.2.3 no se modifica. Esta carpeta es una nueva revisión de trabajo derivada del ZIP fixed11.
