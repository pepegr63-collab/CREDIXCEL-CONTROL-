package com.credixcel.control.network

import kotlinx.serialization.Serializable
import retrofit2.http.Body
import retrofit2.http.POST

@Serializable
data class EnrollRequest(
    val enrollmentCode: String,
    val deviceName: String,
    val androidId: String
)

@Serializable
data class EnrollResponse(
    val deviceId: String,
    val deviceToken: String,
    val status: String,
    val message: String,
    val uninstallBlocked: Boolean = false
)

@Serializable
data class DeviceState(
    val deviceId: String,
    val status: String,
    val message: String? = null,
    val uninstallBlocked: Boolean = false,
    // Missing/null contract state is UNKNOWN, never an implicit authorization to release.
    val contractStatus: String? = null,
    val updatedAt: String? = null
)

@Serializable
data class FcmTokenRequest(val deviceId: String, val deviceToken: String, val fcmToken: String)

@Serializable
data class OrderAckRequest(
    val deviceId: String,
    val deviceToken: String,
    val orderId: String,
    val status: String,
    val result: String
)

interface CredixcelApi {
    @POST("/api/device/enroll")
    suspend fun enroll(@Body request: EnrollRequest): EnrollResponse

    @POST("/api/device/sync")
    suspend fun sync(@Body body: Map<String, String>): DeviceState

    @POST("/api/device/fcm-token")
    suspend fun registerFcmToken(@Body body: FcmTokenRequest): Map<String, Boolean>

    @POST("/api/device/orders/ack")
    suspend fun acknowledgeOrder(@Body body: OrderAckRequest): Map<String, Boolean>
}
