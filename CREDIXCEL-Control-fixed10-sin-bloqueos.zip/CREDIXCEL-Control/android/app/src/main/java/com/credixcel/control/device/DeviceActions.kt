package com.credixcel.control.device

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.UserManager
import com.credixcel.control.MainActivity

/** Android Enterprise policies used by CREDIXCEL on fully-managed devices. */
object DeviceActions {
    private fun dpm(context: Context) =
        context.getSystemService(DevicePolicyManager::class.java)

    private fun admin(context: Context) =
        ComponentName(context, CredixcelDeviceAdminReceiver::class.java)

    fun isAdmin(context: Context): Boolean = dpm(context).isAdminActive(admin(context))

    fun isDeviceOwner(context: Context): Boolean =
        dpm(context).isDeviceOwnerApp(context.packageName)

    fun isLockTaskPermitted(context: Context): Boolean =
        dpm(context).isLockTaskPermitted(context.packageName)

    /** Allow CREDIXCEL in Lock Task and make it the persistent HOME only while restricted. */
    fun configureKiosk(context: Context): Boolean {
        if (!isDeviceOwner(context)) return false
        return try {
            val manager = dpm(context)
            manager.setLockTaskPackages(admin(context), arrayOf(context.packageName))

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                // Keep the power menu and keyguard available; HOME returns to our managed HOME.
                manager.setLockTaskFeatures(
                    admin(context),
                    DevicePolicyManager.LOCK_TASK_FEATURE_HOME or
                        DevicePolicyManager.LOCK_TASK_FEATURE_GLOBAL_ACTIONS or
                        DevicePolicyManager.LOCK_TASK_FEATURE_KEYGUARD
                )
            }

            val homeFilter = IntentFilter(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_HOME)
                addCategory(Intent.CATEGORY_DEFAULT)
            }
            manager.addPersistentPreferredActivity(
                admin(context),
                homeFilter,
                ComponentName(context, MainActivity::class.java)
            )
            manager.isLockTaskPermitted(context.packageName)
        } catch (_: SecurityException) {
            false
        } catch (_: IllegalStateException) {
            false
        }
    }

    /** Remove only the kiosk HOME preference and Lock Task allowlist owned by this DPC. */
    fun clearKioskConfiguration(context: Context): Boolean {
        if (!isDeviceOwner(context)) return false
        return try {
            val manager = dpm(context)
            manager.clearPackagePersistentPreferredActivities(admin(context), context.packageName)
            manager.setLockTaskPackages(admin(context), emptyArray<String>())
            true
        } catch (_: SecurityException) {
            false
        } catch (_: IllegalStateException) {
            false
        }
    }

    fun applyUninstallPolicy(context: Context, blocked: Boolean): Boolean {
        if (!isDeviceOwner(context)) return false
        return runCatching {
            dpm(context).setUninstallBlocked(admin(context), context.packageName, blocked)
        }.isSuccess
    }

    fun applyFactoryResetPolicy(context: Context, blocked: Boolean): Boolean {
        if (!isDeviceOwner(context)) return false
        return runCatching {
            val manager = dpm(context)
            if (blocked) {
                manager.addUserRestriction(admin(context), UserManager.DISALLOW_FACTORY_RESET)
            } else {
                manager.clearUserRestriction(admin(context), UserManager.DISALLOW_FACTORY_RESET)
            }
        }.isSuccess
    }

    fun applySafeBootPolicy(context: Context, blocked: Boolean): Boolean {
        if (!isDeviceOwner(context)) return false
        return runCatching {
            val manager = dpm(context)
            if (blocked) {
                manager.addUserRestriction(admin(context), UserManager.DISALLOW_SAFE_BOOT)
            } else {
                manager.clearUserRestriction(admin(context), UserManager.DISALLOW_SAFE_BOOT)
            }
        }.isSuccess
    }

    /** Apply the non-FRP financing policies. FRP is deliberately not changed without verified Google account IDs. */
    fun applyFinancingProtection(context: Context): Boolean {
        if (!isDeviceOwner(context)) return false
        val uninstall = applyUninstallPolicy(context, true)
        val reset = applyFactoryResetPolicy(context, true)
        val safeBoot = applySafeBootPolicy(context, true)
        return uninstall && reset && safeBoot
    }

    /** Remove financing restrictions only after the server confirms device ACTIVE and contract ACTIVE. */
    fun releaseFinancingProtection(context: Context): Boolean {
        if (!isDeviceOwner(context)) return false
        val uninstall = applyUninstallPolicy(context, false)
        val reset = applyFactoryResetPolicy(context, false)
        val safeBoot = applySafeBootPolicy(context, false)
        return uninstall && reset && safeBoot
    }

    fun lock(context: Context): Boolean {
        if (!isDeviceOwner(context)) return false
        return runCatching {
            dpm(context).lockNow()
        }.isSuccess
    }
}
