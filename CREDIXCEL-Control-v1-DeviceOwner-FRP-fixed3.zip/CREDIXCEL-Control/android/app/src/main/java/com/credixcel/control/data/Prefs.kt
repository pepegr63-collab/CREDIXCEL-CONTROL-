package com.credixcel.control.data

import android.content.Context

class Prefs(context: Context) {
    private val p = context.getSharedPreferences(
        "credixcel",
        Context.MODE_PRIVATE
    )

    var deviceId: String?
        get() = p.getString("device_id", null)
        set(value) {
            p.edit().putString("device_id", value).apply()
        }

    var token: String?
        get() = p.getString("token", null)
        set(value) {
            p.edit().putString("token", value).apply()
        }

    var serverUrl: String
        get() = p.getString("server_url", "https://TU-DOMINIO.example")!!
        set(value) {
            p.edit().putString("server_url", value.trimEnd('/')).apply()
        }
}
