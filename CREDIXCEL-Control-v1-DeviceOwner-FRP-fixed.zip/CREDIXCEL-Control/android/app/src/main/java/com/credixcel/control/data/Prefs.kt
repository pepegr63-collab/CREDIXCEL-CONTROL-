package com.credixcel.control.data

import android.content.Context

class Prefs(context: Context) {
    private val p = context.getSharedPreferences("credixcel", Context.MODE_PRIVATE)
    var deviceId: String? get() = p.getString("device_id", null) set(v) = p.edit().putString("device_id", v).apply()
    var token: String? get() = p.getString("token", null) set(v) = p.edit().putString("token", v).apply()
    var serverUrl: String get() = p.getString("server_url", "https://TU-DOMINIO.example")!! set(v) = p.edit().putString("server_url", v.trimEnd('/')).apply()
}
