﻿package com.credixcel.control

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.credixcel.control.data.Prefs
import com.credixcel.control.device.CredixcelDeviceAdminReceiver
import com.credixcel.control.device.DeviceActions
import com.credixcel.control.network.CredixcelApi
import com.credixcel.control.network.EnrollRequest
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import okhttp3.MediaType.Companion.toMediaType

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { App(Prefs(this)) } }

    @Composable private fun App(prefs: Prefs) {
        var server by remember { mutableStateOf(prefs.serverUrl) }
        var code by remember { mutableStateOf("") }
        var info by remember { mutableStateOf("Equipo no enrolado") }
        var busy by remember { mutableStateOf(false) }
        val scope = rememberCoroutineScope()
        MaterialTheme { Surface(Modifier.fillMaxSize()) { Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("CREDIXCEL Control", style = MaterialTheme.typography.headlineMedium)
            Text("Administración autorizada de dispositivos financiados")
            OutlinedTextField(server, { server = it; prefs.serverUrl = it }, label={Text("Servidor API")}, modifier=Modifier.fillMaxWidth())
            OutlinedTextField(code, { code = it }, label={Text("Código de enrolamiento")}, modifier=Modifier.fillMaxWidth())
            Text(info)
            Button(onClick = { startActivity(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply { putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, ComponentName(this@MainActivity, CredixcelDeviceAdminReceiver::class.java)); putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "CREDIXCEL Control administra este teléfono financiado con autorización y conforme al contrato.") }) }, modifier=Modifier.fillMaxWidth()) { Text("Autorizar administración") }
            Button(enabled=!busy, onClick = { scope.launch {
                busy=true
                try {
                    val api = buildApi(server)
                   val nombreEquipo = "${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}" val r = api.enroll(EnrollRequest(code.trim(), nombreEquipo, Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown"))
                    prefs.deviceId=r.deviceId; prefs.token=r.deviceToken
                    val applied=DeviceActions.applyUninstallPolicy(this@MainActivity, r.uninstallBlocked)
                    info="Enrolado: ${r.status}. Protección aplicada: $applied"
                } catch(e:Exception){ info="Error: ${e.message}" } finally { busy=false }
            }}, modifier=Modifier.fillMaxWidth()) { Text(if(busy) "Conectando…" else "Enrolar dispositivo") }
            OutlinedButton(enabled=prefs.deviceId!=null&&!busy, onClick={ scope.launch {
                busy=true
                try { val api=buildApi(server); val r=api.sync(mapOf("deviceId" to prefs.deviceId!!,"deviceToken" to prefs.token!!)); val applied=DeviceActions.applyUninstallPolicy(this@MainActivity,r.uninstallBlocked); info="Estado: ${r.status}. Protección: ${if(applied) "activa" else "requiere Device Owner"}" }
                catch(e:Exception){info="Error de sincronización: ${e.message}"} finally{busy=false}
            }}, modifier=Modifier.fillMaxWidth()){Text("Sincronizar estado")}
            Text("Device Owner: ${DeviceActions.isDeviceOwner(this@MainActivity)}")
            Text("La protección contra desinstalación requiere que el equipo haya sido aprovisionado como dispositivo administrado (Device Owner).", style=MaterialTheme.typography.bodySmall)
        } } }
    }

    private fun buildApi(url:String): CredixcelApi {
        val json=Json{ignoreUnknownKeys=true}
        return Retrofit.Builder().baseUrl(url.trimEnd('/')+"/").client(OkHttpClient.Builder().build()).addConverterFactory(json.asConverterFactory("application/json".toMediaType())).build().create(CredixcelApi::class.java)
    }
}
