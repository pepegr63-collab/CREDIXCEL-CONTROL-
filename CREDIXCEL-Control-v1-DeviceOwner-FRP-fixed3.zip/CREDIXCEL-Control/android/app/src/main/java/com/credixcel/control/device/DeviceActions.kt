package com.credixcel.control.device

import android.app.admin.DevicePolicyManager
import android.app.admin.FactoryResetProtectionPolicy
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.UserManager

/** Official Android Enterprise device-owner policies for CREDIXCEL financed devices. */
object DeviceActions {
    private fun dpm(context: Context) = context.getSystemService(DevicePolicyManager::class.java)
    private fun admin(context: Context) = ComponentName(context, CredixcelDeviceAdminReceiver::class.java)

    fun isAdmin(context: Context): Boolean = dpm(context).isAdminActive(admin(context))
    fun isDeviceOwner(context: Context): Boolean = dpm(context).isDeviceOwnerApp(context.packageName)

    fun applyUninstallPolicy(context: Context, blocked: Boolean): Boolean {
        if (!isDeviceOwner(context)) return false
        dpm(context).setUninstallBlocked(admin(context), context.packageName, blocked)
        return true
    }

    /**
     * Prevents factory reset from Android Settings while the financing is active.
     * Android documents this as DISALLOW_FACTORY_RESET for fully managed devices.
     */
    fun applyFactoryResetPolicy(context: Context, blocked: Boolean): Boolean {
        if (!isDeviceOwner(context)) return false
        val manager = dpm(context)
        if (blocked) {
            manager.addUserRestriction(admin(context), UserManager.DISALLOW_FACTORY_RESET)
        } else {
            manager.clearUserRestriction(admin(context), UserManager.DISALLOW_FACTORY_RESET)
        }
        return true
    }

    /** Prevents Safe Mode, which otherwise can stop a DPC from launching normally. */
    fun applySafeBootPolicy(context: Context, blocked: Boolean): Boolean {
        if (!isDeviceOwner(context)) return false
        val manager = dpm(context)
        if (blocked) {
            manager.addUserRestriction(admin(context), UserManager.DISALLOW_SAFE_BOOT)
        } else {
            manager.clearUserRestriction(admin(context), UserManager.DISALLOW_SAFE_BOOT)
        }
        return true
    }

    /**
     * Configures Android's official FRP policy. The supplied values must be
     * Google account IDs accepted by the FRP management agent, not passwords.
     * API 30+ only; support still depends on the device/FRP agent.
     */
    fun applyFrpPolicy(context: Context, enabled: Boolean, accountIds: List<String>): Boolean {
        if (!isDeviceOwner(context) || Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return false
        val manager = dpm(context)
        return try {
            val policy = FactoryResetProtectionPolicy.Builder()
                .setFactoryResetProtectionEnabled(enabled)
                .setFactoryResetProtectionAccounts(accountIds)
                .build()
            manager.setFactoryResetProtectionPolicy(admin(context), policy)

            // Android Enterprise documents notifying Google Play services that FRP changed.
            context.sendBroadcast(Intent("com.google.android.gms.auth.FRP_CONFIG_CHANGED").apply {
                setPackage("com.google.android.gms")
            })
            true
        } catch (_: UnsupportedOperationException) {
            false
        } catch (_: SecurityException) {
            false
        }
    }

    /** Apply all protections used while a financing contract is active. */
    fun applyFinancingProtection(
        context: Context,
        frpAccountIds: List<String>
    ): Boolean {
        if (!isDeviceOwner(context)) return false
        val uninstall = applyUninstallPolicy(context, true)
        val reset = applyFactoryResetPolicy(context, true)
        val safeBoot = applySafeBootPolicy(context, true)
        val frp = applyFrpPolicy(context, true, frpAccountIds)
        return uninstall && reset && safeBoot && frp
    }

    /** Remove policies when the financing is fully paid and the device is released. */
    fun releaseFinancingProtection(
        context: Context,
        clearFrpAccountIds: List<String> = emptyList()
    ): Boolean {
        if (!isDeviceOwner(context)) return false
        val uninstall = applyUninstallPolicy(context, false)
        val reset = applyFactoryResetPolicy(context, false)
        val safeBoot = applySafeBootPolicy(context, false)
        val frp = applyFrpPolicy(context, false, clearFrpAccountIds)
        return uninstall && reset && safeBoot && frp
    }

    fun lock(context: Context): Boolean {
        if (!isDeviceOwner(context)) return false
        dpm(context).lockNow()
        return true
    }
}
