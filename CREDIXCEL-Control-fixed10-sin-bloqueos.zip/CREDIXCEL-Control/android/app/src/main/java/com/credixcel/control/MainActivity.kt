package com.credixcel.control

import android.app.ActivityManager
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.credixcel.control.data.Prefs
import com.credixcel.control.device.DeviceActions
import com.credixcel.control.network.CredixcelApi
import com.credixcel.control.network.EnrollRequest
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json
import okhttp3.OkHttpClient
import okhttp3.MediaType.Companion.toMediaType
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import java.net.URL

private const val DEFAULT_SERVER = "https://credixcel-control-server.onrender.com"

class MainActivity : ComponentActivity() {
    private lateinit var prefs: Prefs

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)

        if (prefs.serverUrl.isBlank() || prefs.serverUrl.contains("TU-DOMINIO")) {
            prefs.serverUrl = DEFAULT_SERVER
        }

        setContent { App(prefs) }
    }

    /** A previously authorized kiosk is re-entered whenever Android recreates this HOME activity. */
    override fun onResume() {
        super.onResume()
        if (!::prefs.isInitialized || !prefs.protectionActive) return

        if (DeviceActions.configureKiosk(this) && DeviceActions.isLockTaskPermitted(this)) {
            val manager = getSystemService(ActivityManager::class.java)
            if (manager.lockTaskModeState == ActivityManager.LOCK_TASK_MODE_NONE) {
                runCatching { startLockTask() }
            }
        }
    }

    private fun activateKiosk(): String {
        if (!DeviceActions.isDeviceOwner(this)) {
            return "El servidor indicó LOCKED, pero esta aplicación no tiene autorización Device Owner. No se pudo activar Lock Task."
        }

        // Persist first so an Activity/process restart cannot silently discard an authorized lock.
        prefs.protectionActive = true
        val kioskReady = DeviceActions.configureKiosk(this)
        if (!kioskReady) {
            return "Se recibió LOCKED y se guardó el estado, pero Android rechazó la configuración de Lock Task o HOME persistente."
        }

        val policiesApplied = DeviceActions.applyFinancingProtection(this)
        return try {
            val manager = getSystemService(ActivityManager::class.java)
            if (manager.lockTaskModeState == ActivityManager.LOCK_TASK_MODE_NONE) {
                startLockTask()
            }
            if (policiesApplied) {
                "Restricción LOCKED activada mediante Lock Task. La recuperación de HOME queda configurada para el reinicio."
            } else {
                "Lock Task activado. Algunas políticas adicionales de administración no pudieron aplicarse; la restricción principal permanece activa."
            }
        } catch (e: Exception) {
            "La autorización LOCKED quedó guardada, pero Android no permitió iniciar Lock Task: ${e.localizedMessage ?: e.javaClass.simpleName}"
        }
    }

    private fun releaseKiosk(): String {
        if (!DeviceActions.isDeviceOwner(this)) {
            return "El servidor confirmó ACTIVE + ACTIVE, pero no se pudo retirar la configuración porque CREDIXCEL ya no es Device Owner."
        }

        // This function is called only after an authenticated response explicitly says ACTIVE + ACTIVE.
        val lockTaskStopped = runCatching {
            val manager = getSystemService(ActivityManager::class.java)
            if (manager.lockTaskModeState != ActivityManager.LOCK_TASK_MODE_NONE) stopLockTask()
            true
        }.getOrDefault(false)

        val kioskCleared = DeviceActions.clearKioskConfiguration(this)
        val policiesReleased = DeviceActions.releaseFinancingProtection(this)
        prefs.protectionActive = false

        // Once the persistent HOME preference is cleared, Android resolves HOME to the user's launcher.
        val homeIntent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_HOME)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        runCatching { startActivity(homeIntent) }

        return when {
            lockTaskStopped && kioskCleared && policiesReleased ->
                "Liberación completada: Lock Task retirado, políticas liberadas y HOME normal solicitado."
            else ->
                "Se recibió ACTIVE + ACTIVE y se detuvo la restricción local. Atención: alguna limpieza de políticas o HOME no se confirmó (Lock Task=$lockTaskStopped, HOME=$kioskCleared, políticas=$policiesReleased)."
        }
    }

    @Composable
    private fun App(prefs: Prefs) {
        var server by remember { mutableStateOf(prefs.serverUrl) }
        var code by remember { mutableStateOf("") }
        var info by remember {
            mutableStateOf(
                if (prefs.protectionActive) {
                    "Restricción local autorizada guardada. Sincroniza para confirmar el estado actual del panel."
                } else if (!prefs.deviceId.isNullOrBlank() && !prefs.token.isNullOrBlank()) {
                    "Dispositivo enrolado. Pulsa sincronizar para consultar el estado."
                } else {
                    "Equipo no enrolado"
                }
            )
        }
        var deviceId by remember { mutableStateOf(prefs.deviceId) }
        var hasCredentials by remember {
            mutableStateOf(!prefs.deviceId.isNullOrBlank() && !prefs.token.isNullOrBlank())
        }
        var busy by remember { mutableStateOf(false) }
        var lastStatus by remember { mutableStateOf(prefs.lastDeviceStatus ?: "Sin consultar") }
        var contractStatus by remember { mutableStateOf(prefs.lastContractStatus ?: "Sin consultar") }
        var serverMessage by remember { mutableStateOf("") }
        var showAdminDialog by remember { mutableStateOf(false) }
        var adminStatus by remember { mutableStateOf("") }
        val scope = rememberCoroutineScope()
        val isOwner = DeviceActions.isDeviceOwner(this@MainActivity)

        MaterialTheme {
            Surface(Modifier.fillMaxSize()) {
                Column(
                    Modifier.fillMaxSize().padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("CREDIXCEL Control", style = MaterialTheme.typography.headlineMedium)
                    Text("Administración autorizada de dispositivos financiados")

                    OutlinedTextField(
                        value = server,
                        onValueChange = { server = it; prefs.serverUrl = it },
                        label = { Text("Servidor API") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = code,
                        onValueChange = { code = it.uppercase().trim() },
                        label = { Text("Código de enrolamiento") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Text("Estado del dispositivo: $lastStatus")
                    Text("Estado del contrato: $contractStatus")
                    Text("Restricción local: ${if (prefs.protectionActive) "ACTIVA" else "INACTIVA"}")
                    if (serverMessage.isNotBlank()) Text("Mensaje: $serverMessage")
                    Text("Dispositivo enrolado: ${if (hasCredentials) "Sí" else "No"}")
                    Text("Device Owner: ${if (isOwner) "Sí" else "No"}")

                    Button(
                        enabled = !busy,
                        onClick = {
                            val owner = DeviceActions.isDeviceOwner(this@MainActivity)
                            val admin = DeviceActions.isAdmin(this@MainActivity)
                            adminStatus = buildString {
                                appendLine("Device Owner: ${if (owner) "ACTIVO" else "NO ACTIVO"}")
                                appendLine("Administrador: ${if (admin) "ACTIVO" else "NO ACTIVO"}")
                                append(if (owner) {
                                    "CREDIXCEL tiene autorización de propietario del dispositivo."
                                } else {
                                    "CREDIXCEL no tiene autorización de propietario del dispositivo."
                                })
                            }
                            showAdminDialog = true
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Ver autorización de administrador") }

                    if (showAdminDialog) {
                        AlertDialog(
                            onDismissRequest = { showAdminDialog = false },
                            title = { Text("Autorización de administrador") },
                            text = { Text(adminStatus) },
                            confirmButton = {
                                TextButton(onClick = { showAdminDialog = false }) { Text("Aceptar") }
                            }
                        )
                    }

                    Button(
                        enabled = !busy && code.isNotBlank(),
                        onClick = {
                            scope.launch {
                                busy = true
                                try {
                                    val response = buildApi(server).enroll(
                                        EnrollRequest(
                                            code.trim(),
                                            "${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}",
                                            Settings.Secure.getString(
                                                contentResolver,
                                                Settings.Secure.ANDROID_ID
                                            ) ?: "unknown"
                                        )
                                    )
                                    prefs.deviceId = response.deviceId
                                    prefs.token = response.deviceToken
                                    deviceId = response.deviceId
                                    hasCredentials = true
                                    lastStatus = response.status
                                    prefs.lastDeviceStatus = response.status
                                    contractStatus = "Pendiente de consulta"
                                    info = "Enrolamiento completado. Sincroniza para recibir el estado autenticado del dispositivo y del contrato."
                                } catch (e: Exception) {
                                    info = "Error de enrolamiento: ${e.localizedMessage ?: e.javaClass.simpleName}"
                                } finally {
                                    busy = false
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(if (busy) "Conectando…" else "Enrolar dispositivo") }

                    OutlinedButton(
                        enabled = hasCredentials && !busy,
                        onClick = {
                            scope.launch {
                                busy = true
                                try {
                                    val id = deviceId ?: prefs.deviceId
                                        ?: error("No hay ID de dispositivo guardado")
                                    val token = prefs.token
                                        ?: error("No hay credencial guardada; vuelve a enrolar")
                                    val state = buildApi(server).sync(
                                        mapOf("deviceId" to id, "deviceToken" to token)
                                    )

                                    val device = state.status.trim().uppercase()
                                    val contract = state.contractStatus?.trim()?.uppercase()
                                    lastStatus = device
                                    contractStatus = contract ?: "DESCONOCIDO"
                                    prefs.lastDeviceStatus = device
                                    prefs.lastContractStatus = contract
                                    serverMessage = state.message.orEmpty()

                                    info = when {
                                        device == "LOCKED" -> activateKiosk()
                                        device == "ACTIVE" && contract == "ACTIVE" -> releaseKiosk()
                                        else -> if (prefs.protectionActive) {
                                            "Estado recibido ($device / ${contract ?: "DESCONOCIDO"}). No existe autorización explícita ACTIVE + ACTIVE; se conserva la restricción."
                                        } else {
                                            "Estado recibido ($device / ${contract ?: "DESCONOCIDO"}). No se activa ni se libera ninguna restricción sin una condición autorizada explícita."
                                        }
                                    }
                                } catch (e: Exception) {
                                    // Network/authentication failures never clear a previously authorized local restriction.
                                    info = "Error de sincronización: ${e.localizedMessage ?: e.javaClass.simpleName}. Se conserva el último estado local autorizado."
                                } finally {
                                    busy = false
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(if (busy) "Sincronizando…" else "Sincronizar estado del panel") }

                    Text(info, style = MaterialTheme.typography.bodyMedium)
                    Text(
                        "LOCKED activa Lock Task. La liberación requiere que el servidor confirme explícitamente dispositivo ACTIVE y contrato ACTIVE. Los errores de conexión no liberan el equipo.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }

    private fun buildApi(rawUrl: String): CredixcelApi {
        val normalized = rawUrl.trim().trimEnd('/')
        require(normalized.startsWith("https://", ignoreCase = true)) {
            "El servidor debe usar HTTPS"
        }
        val parsed = URL(normalized)
        require(parsed.host.isNotBlank()) { "La dirección del servidor no es válida" }
        val json = Json { ignoreUnknownKeys = true }
        return Retrofit.Builder()
            .baseUrl("$normalized/")
            .client(OkHttpClient.Builder().build())
            .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
            .build()
            .create(CredixcelApi::class.java)
    }
}
