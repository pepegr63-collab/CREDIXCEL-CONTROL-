package com.credixcel.control.network

import kotlinx.serialization.Serializable
import retrofit2.http.Body
import retrofit2.http.POST

@Serializable data class EnrollRequest(val enrollmentCode: String, val deviceName: String, val androidId: String)
@Serializable data class EnrollResponse(val deviceId: String, val deviceToken: String, val status: String, val message: String, val uninstallBlocked: Boolean = false)
@Serializable data class DeviceState(val deviceId: String, val status: String, val message: String? = null, val uninstallBlocked: Boolean = false, val contractStatus: String = "ACTIVE", val updatedAt: String? = null)

interface CredixcelApi {
    @POST("/api/device/enroll") suspend fun enroll(@Body request: EnrollRequest): EnrollResponse
    @POST("/api/device/sync") suspend fun sync(@Body body: Map<String,String>): DeviceState
}
