package com.credixcel.control.provisioning

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** Shows a clear disclosure and waits for the user to continue setup. */
class AdminPolicyComplianceActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val padding = (24 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(padding, padding, padding, padding)
        }
        val message = TextView(this).apply {
            text = "CREDIXCEL Control se configurará como administrador del dispositivo. " +
                "La organización autorizada podrá aplicar políticas de administración " +
                "al equipo financiado, de acuerdo con el contrato y las autorizaciones correspondientes."
            textSize = 18f
        }
        val continueButton = Button(this).apply {
            text = "Continuar configuración"
            setOnClickListener {
                setResult(RESULT_OK)
                finish()
            }
        }
        layout.addView(message, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ))
        layout.addView(continueButton, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = padding })
        setContentView(layout)
    }
}
