import express from 'express';
import cors from 'cors';
import Database from 'better-sqlite3';
import jwt from 'jsonwebtoken';
import crypto from 'crypto';
import { cert, getApps, initializeApp } from 'firebase-admin/app';
import { getMessaging } from 'firebase-admin/messaging';
import path from 'path';
import { fileURLToPath } from 'url';

const app = express();
app.use(cors());
app.use(express.json());
const db = new Database(process.env.DB_PATH || 'credixcel.db');
const now = () => new Date().toISOString();
const __dirname = path.dirname(fileURLToPath(import.meta.url));

db.exec(`
CREATE TABLE IF NOT EXISTS clients(id TEXT PRIMARY KEY, name TEXT NOT NULL, phone TEXT, email TEXT, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS contracts(id TEXT PRIMARY KEY, client_id TEXT NOT NULL, device_id TEXT, total_amount REAL DEFAULT 0, monthly_amount REAL DEFAULT 0, due_day INTEGER DEFAULT 1, status TEXT DEFAULT 'ACTIVE', created_at TEXT NOT NULL, FOREIGN KEY(client_id) REFERENCES clients(id));
CREATE TABLE IF NOT EXISTS payments(id TEXT PRIMARY KEY, contract_id TEXT NOT NULL, amount REAL NOT NULL, due_date TEXT NOT NULL, paid_at TEXT, status TEXT DEFAULT 'PENDING', FOREIGN KEY(contract_id) REFERENCES contracts(id));
CREATE TABLE IF NOT EXISTS devices(id TEXT PRIMARY KEY, enrollment_code TEXT UNIQUE NOT NULL, device_token TEXT UNIQUE, device_name TEXT, android_id TEXT, status TEXT DEFAULT 'ACTIVE', message TEXT, uninstall_blocked INTEGER DEFAULT 0, updated_at TEXT);
CREATE TABLE IF NOT EXISTS audit(id TEXT PRIMARY KEY, action TEXT NOT NULL, entity TEXT, entity_id TEXT, details TEXT, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS device_orders(id TEXT PRIMARY KEY, device_id TEXT NOT NULL, action TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'PENDING', result TEXT, created_at TEXT NOT NULL, acknowledged_at TEXT, FOREIGN KEY(device_id) REFERENCES devices(id));
`);

// Migración compatible: agrega los campos IMEI sin borrar los dispositivos existentes.
const deviceColumns = db.prepare('PRAGMA table_info(devices)').all().map(column => column.name);
for (const [name, type] of [
  ['imei_1', 'TEXT'],
  ['imei_2', 'TEXT'],
  ['imei_source', "TEXT DEFAULT 'pending'"],
  ['imei_updated_at', 'TEXT'],
  ['fcm_token', 'TEXT']
]) {
  if (!deviceColumns.includes(name)) db.exec(`ALTER TABLE devices ADD COLUMN ${name} ${type}`);
}

function validImei(value) {
  if (value == null || value === '') return true;
  const digits = String(value).replace(/[ -]/g, '');
  if (!/^\d{15}$/.test(digits)) return false;
  let sum = 0;
  for (let i = 0; i < digits.length; i++) {
    let n = Number(digits[i]);
    if (i % 2 === digits.length % 2) { n *= 2; if (n > 9) n -= 9; }
    sum += n;
  }
  return sum % 10 === 0;
}

const ADMIN_SECRET = process.env.ADMIN_SECRET || 'CHANGE_ME_IN_PRODUCTION';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'CHANGE_ME_IN_PRODUCTION';
let firebaseMessaging = null;
try {
  const rawServiceAccount = process.env.FIREBASE_SERVICE_ACCOUNT_JSON;
  if (rawServiceAccount) {
    const serviceAccount = JSON.parse(rawServiceAccount);
    const app = getApps()[0] || initializeApp({ credential: cert(serviceAccount) });
    firebaseMessaging = getMessaging(app);
  }
} catch (error) {
  console.error('Firebase Admin no pudo inicializarse:', error.message);
}
const audit = (action, entity, entityId, details='') => db.prepare('INSERT INTO audit(id,action,entity,entity_id,details,created_at) VALUES(?,?,?,?,?,?)').run(crypto.randomUUID(), action, entity, entityId, details, now());
function admin(req,res,next){ const h=req.headers.authorization||''; try { jwt.verify(h.replace('Bearer ',''), ADMIN_SECRET); next(); } catch { res.status(401).json({error:'Unauthorized'}); } }

app.use(express.static(path.join(__dirname,'../public')));
app.get('/health',(req,res)=>res.json({ok:true,service:'CREDIXCEL Control'}));
app.post('/api/admin/login',(req,res)=>{ if(req.body.username!=='admin'||req.body.password!==ADMIN_PASSWORD) return res.status(401).json({error:'Invalid credentials'}); res.json({token:jwt.sign({role:'admin'},ADMIN_SECRET,{expiresIn:'8h'})}); });

app.post('/api/device/enroll',(req,res)=>{
 const {enrollmentCode,deviceName,androidId}=req.body||{};
 const row=db.prepare('SELECT * FROM devices WHERE enrollment_code=?').get(enrollmentCode);
 if(!row) return res.status(404).json({error:'Invalid enrollment code'});
 const token=crypto.randomBytes(32).toString('hex');
 db.prepare('UPDATE devices SET device_token=?,device_name=?,android_id=?,updated_at=? WHERE id=?').run(token,deviceName,androidId,now(),row.id);
 audit('DEVICE_ENROLLED','device',row.id,deviceName||'');
 res.json({deviceId:row.id,deviceToken:token,status:row.status,message:row.message||'',uninstallBlocked:Boolean(row.uninstall_blocked)});
});

app.post('/api/device/sync',(req,res)=>{
 const {deviceId,deviceToken}=req.body||{};
 const row=db.prepare('SELECT d.*, c.status contract_status FROM devices d LEFT JOIN contracts c ON c.device_id=d.id WHERE d.id=? AND d.device_token=?').get(deviceId,deviceToken);
 if(!row) return res.status(401).json({error:'Unauthorized device'});
 db.prepare('UPDATE devices SET updated_at=? WHERE id=?').run(now(),deviceId);
 res.json({deviceId:row.id,status:row.status,message:row.message||'',uninstallBlocked:Boolean(row.uninstall_blocked),contractStatus:row.contract_status||'UNKNOWN',updatedAt:row.updated_at});
});

app.get('/api/admin/dashboard',admin,(req,res)=>{
 const clients=db.prepare('SELECT COUNT(*) c FROM clients').get().c;
 const devices=db.prepare('SELECT COUNT(*) c FROM devices').get().c;
 const active=db.prepare("SELECT COUNT(*) c FROM devices WHERE status='ACTIVE'").get().c;
 const due=db.prepare("SELECT COUNT(*) c FROM devices WHERE status='PAYMENT_DUE'").get().c;
 const locked=db.prepare("SELECT COUNT(*) c FROM devices WHERE status='LOCKED'").get().c;
 const pending=db.prepare("SELECT COALESCE(SUM(amount),0) total FROM payments WHERE status='PENDING'").get().total;
 res.json({clients,devices,active,due,locked,pending});
});
app.get('/api/admin/devices',admin,(req,res)=>res.json(db.prepare(`SELECT d.id,d.enrollment_code,d.device_name,d.android_id,d.status,d.message,d.uninstall_blocked,d.updated_at,d.imei_1,d.imei_2,d.imei_source,d.imei_updated_at,c.name client_name,c.id client_id,ct.id contract_id,ct.status contract_status FROM devices d LEFT JOIN contracts ct ON ct.device_id=d.id LEFT JOIN clients c ON c.id=ct.client_id ORDER BY d.updated_at DESC`).all()));
app.post('/api/admin/devices',admin,(req,res)=>{ const id=crypto.randomUUID(), code=crypto.randomBytes(5).toString('hex').toUpperCase(); db.prepare('INSERT INTO devices(id,enrollment_code,updated_at) VALUES(?,?,?)').run(id,code,now()); audit('DEVICE_CREATED','device',id,code); res.json({id,enrollmentCode:code}); });
app.post('/api/admin/devices/:id/state',admin,async (req,res)=>{
 const {status,message=''}=req.body;
 if(!['ACTIVE','LOCKED','PAYMENT_DUE'].includes(status)) return res.status(400).json({error:'Invalid state'});
 const device=db.prepare('SELECT * FROM devices WHERE id=?').get(req.params.id);
 if(!device) return res.status(404).json({error:'Device not found'});
 if(status==='ACTIVE') {
   const contract=db.prepare('SELECT status FROM contracts WHERE device_id=? ORDER BY created_at DESC LIMIT 1').get(device.id);
   if(!contract || contract.status!=='ACTIVE') return res.status(409).json({error:'No se puede enviar UNLOCK: el contrato no está ACTIVE.'});
 }
 db.prepare('UPDATE devices SET status=?,message=?,updated_at=? WHERE id=?').run(status,message,now(),req.params.id);
 audit('DEVICE_STATE_CHANGED','device',req.params.id,`${status}: ${message}`);
 let order=null, delivery='NOT_SENT';
 const action=status==='LOCKED'?'LOCK':status==='ACTIVE'?'UNLOCK':null;
 if(action && device.device_token && device.fcm_token) {
   if(!firebaseMessaging) delivery='FCM_NOT_CONFIGURED';
   else {
     order=crypto.randomUUID(); const issuedAt=String(Date.now());
     const signature=crypto.createHmac('sha256',device.device_token).update(`${order}.${action}.${issuedAt}`).digest('hex');
     db.prepare('INSERT INTO device_orders(id,device_id,action,status,created_at) VALUES(?,?,?,?,?)').run(order,device.id,action,'PENDING',now());
     try {
       await firebaseMessaging.send({token:device.fcm_token,data:{orderId:order,action,issuedAt,signature},android:{priority:'high'}});
       delivery='SENT'; audit('DEVICE_ORDER_SENT','device',device.id,`${action}:${order}`);
     } catch(error) {
       delivery='SEND_FAILED'; db.prepare("UPDATE device_orders SET status='FAILED',result=? WHERE id=?").run(String(error.message).slice(0,300),order);
       audit('DEVICE_ORDER_FAILED','device',device.id,`${action}:${String(error.message).slice(0,180)}`);
     }
   }
 } else if(action) delivery=device.fcm_token?'NO_DEVICE_CREDENTIAL':'NO_FCM_TOKEN';
 res.json({updated:true,orderId:order,action,delivery});
});

app.post('/api/device/fcm-token',(req,res)=>{
 const {deviceId,deviceToken,fcmToken}=req.body||{};
 if(!deviceId||!deviceToken||!fcmToken||String(fcmToken).length>4096) return res.status(400).json({error:'Invalid token registration'});
 const info=db.prepare('UPDATE devices SET fcm_token=?,updated_at=? WHERE id=? AND device_token=?').run(fcmToken,now(),deviceId,deviceToken);
 if(!info.changes) return res.status(401).json({error:'Unauthorized device'});
 audit('FCM_TOKEN_REGISTERED','device',deviceId,'FCM token updated'); res.json({registered:true});
});

app.post('/api/device/orders/ack',(req,res)=>{
 const {deviceId,deviceToken,orderId,status,result=''}=req.body||{};
 if(!deviceId||!deviceToken||!orderId||!['COMPLETED','FAILED'].includes(status)) return res.status(400).json({error:'Invalid acknowledgement'});
 const device=db.prepare('SELECT id FROM devices WHERE id=? AND device_token=?').get(deviceId,deviceToken);
 if(!device) return res.status(401).json({error:'Unauthorized device'});
 const info=db.prepare('UPDATE device_orders SET status=?,result=?,acknowledged_at=? WHERE id=? AND device_id=?').run(status,String(result).slice(0,500),now(),orderId,deviceId);
 if(!info.changes) return res.status(404).json({error:'Order not found'});
 audit('DEVICE_ORDER_ACK','device',deviceId,`${orderId}:${status}:${String(result).slice(0,100)}`);
 res.json({acknowledged:true});
});

app.get('/api/admin/devices/:id/orders',admin,(req,res)=>res.json(db.prepare('SELECT id,action,status,result,created_at,acknowledged_at FROM device_orders WHERE device_id=? ORDER BY created_at DESC LIMIT 30').all(req.params.id)));
app.put('/api/admin/devices/:id/imei',admin,(req,res)=>{
 const imei1=String(req.body?.imei1||'').replace(/[ -]/g,'');
 const imei2=String(req.body?.imei2||'').replace(/[ -]/g,'');
 if(!validImei(imei1)||!validImei(imei2)) return res.status(400).json({error:'Cada IMEI debe tener 15 dígitos y pasar la validación.'});
 if(imei1 && imei2 && imei1===imei2) return res.status(400).json({error:'IMEI 1 e IMEI 2 deben ser distintos.'});
 const device=db.prepare('SELECT id FROM devices WHERE id=?').get(req.params.id);
 if(!device) return res.status(404).json({error:'Dispositivo no encontrado'});
 for(const value of [imei1,imei2].filter(Boolean)) {
   const duplicate=db.prepare('SELECT id FROM devices WHERE id<>? AND (imei_1=? OR imei_2=?) LIMIT 1').get(req.params.id,value,value);
   if(duplicate) return res.status(409).json({error:'Ese IMEI ya está registrado en otro dispositivo.'});
 }
 const stamp=now();
 db.prepare("UPDATE devices SET imei_1=?,imei_2=?,imei_source='manual',imei_updated_at=?,updated_at=? WHERE id=?").run(imei1||null,imei2||null,stamp,stamp,req.params.id);
 // No guardar los números IMEI en la bitácora.
 audit('DEVICE_IMEI_UPDATED','device',req.params.id,'IMEI actualizado manualmente');
 res.json({updated:true,source:'manual',updatedAt:stamp});
});

app.get('/api/admin/clients',admin,(req,res)=>res.json(db.prepare('SELECT * FROM clients ORDER BY created_at DESC').all()));
app.post('/api/admin/clients',admin,(req,res)=>{ const {name,phone='',email=''}=req.body; if(!name) return res.status(400).json({error:'Name required'}); const id=crypto.randomUUID(); db.prepare('INSERT INTO clients(id,name,phone,email,created_at) VALUES(?,?,?,?,?)').run(id,name,phone,email,now()); audit('CLIENT_CREATED','client',id,name); res.json({id}); });

app.get('/api/admin/contracts',admin,(req,res)=>res.json(db.prepare(`SELECT ct.*, c.name client_name, d.device_name FROM contracts ct JOIN clients c ON c.id=ct.client_id LEFT JOIN devices d ON d.id=ct.device_id ORDER BY ct.created_at DESC`).all()));
app.post('/api/admin/contracts',admin,(req,res)=>{ const {clientId,deviceId=null,totalAmount=0,monthlyAmount=0,dueDay=1}=req.body; if(!clientId) return res.status(400).json({error:'clientId required'}); const id=crypto.randomUUID(); db.prepare('INSERT INTO contracts(id,client_id,device_id,total_amount,monthly_amount,due_day,status,created_at) VALUES(?,?,?,?,?,?,?,?)').run(id,clientId,deviceId,totalAmount,monthlyAmount,dueDay,'ACTIVE',now()); audit('CONTRACT_CREATED','contract',id); res.json({id}); });

app.get('/api/admin/payments',admin,(req,res)=>res.json(db.prepare(`SELECT p.*, ct.client_id, c.name client_name FROM payments p JOIN contracts ct ON ct.id=p.contract_id JOIN clients c ON c.id=ct.client_id ORDER BY p.due_date DESC`).all()));
app.post('/api/admin/payments',admin,(req,res)=>{ const {contractId,amount,dueDate}=req.body; if(!contractId||!amount||!dueDate) return res.status(400).json({error:'contractId, amount and dueDate required'}); const id=crypto.randomUUID(); db.prepare('INSERT INTO payments(id,contract_id,amount,due_date,status) VALUES(?,?,?,?,?)').run(id,contractId,amount,dueDate,'PENDING'); audit('PAYMENT_CREATED','payment',id); res.json({id}); });
app.post('/api/admin/payments/:id/pay',admin,(req,res)=>{ const info=db.prepare("UPDATE payments SET status='PAID',paid_at=? WHERE id=?").run(now(),req.params.id); audit('PAYMENT_PAID','payment',req.params.id); res.json({updated:info.changes}); });

app.get('/api/admin/audit',admin,(req,res)=>res.json(db.prepare('SELECT * FROM audit ORDER BY created_at DESC LIMIT 200').all()));

const port=process.env.PORT||3000;
app.listen(port,()=>console.log(`CREDIXCEL Control API running on :${port}`));
