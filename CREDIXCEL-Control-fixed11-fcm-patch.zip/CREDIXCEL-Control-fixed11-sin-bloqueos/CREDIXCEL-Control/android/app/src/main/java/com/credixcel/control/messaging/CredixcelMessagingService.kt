package com.credixcel.control.messaging

import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.credixcel.control.data.Prefs
import com.credixcel.control.device.DeviceActions
import com.credixcel.control.network.FcmTokenRequest
import com.credixcel.control.network.OrderAckRequest
import com.credixcel.control.network.CredixcelApi
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json
import okhttp3.OkHttpClient
import okhttp3.MediaType.Companion.toMediaType
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

class CredixcelMessagingService : FirebaseMessagingService() {
    override fun onNewToken(token: String) {
        super.onNewToken(token)
        val prefs = Prefs(applicationContext)
        prefs.fcmToken = token
        registerToken(prefs, token)
    }

    override fun onMessageReceived(message: RemoteMessage) {
        super.onMessageReceived(message)
        val data = message.data
        val orderId = data["orderId"] ?: return
        val action = data["action"] ?: return
        val issuedAt = data["issuedAt"] ?: return
        val signature = data["signature"] ?: return
        val prefs = Prefs(applicationContext)
        val deviceId = prefs.deviceId ?: return
        val deviceToken = prefs.token ?: return
        val issuedMillis = issuedAt.toLongOrNull() ?: return
        if (kotlin.math.abs(System.currentTimeMillis() - issuedMillis) > 5 * 60 * 1000L) return
        val canonical = "$orderId.$action.$issuedAt"
        if (!constantTimeEquals(hmacSha256(deviceToken, canonical), signature)) return
        if (!prefs.markOrderProcessed(orderId)) return

        val result = when (action) {
            "LOCK" -> {
                prefs.protectionActive = true
                val configured = DeviceActions.isDeviceOwner(this) &&
                    DeviceActions.configureKiosk(this) &&
                    DeviceActions.applyFinancingProtection(this)
                val locked = configured && DeviceActions.lock(this)
                if (locked) "LOCKED_BY_FCM" else "LOCK_FAILED_PROTECTION_RETAINED"
            }
            "UNLOCK" -> {
                // The server only issues UNLOCK after confirming device ACTIVE + contract ACTIVE.
                // Activity resumes to stop its own Lock Task session; do not claim success prematurely.
                prefs.protectionActive = true
                val homeCleared = DeviceActions.clearKioskConfiguration(this)
                val policiesReleased = DeviceActions.releaseFinancingProtection(this)
                if (homeCleared && policiesReleased) {
                    prefs.protectionActive = false
                    "UNLOCK_CONFIGURATION_CLEARED_ACTIVITY_EXIT_UNVERIFIED"
                } else {
                    prefs.protectionActive = true
                    "UNLOCK_FAILED_PROTECTION_RETAINED"
                }
            }
            else -> return
        }
        acknowledge(prefs, orderId, result)
    }

    private fun registerToken(prefs: Prefs, fcmToken: String) {
        val id = prefs.deviceId ?: return
        val deviceToken = prefs.token ?: return
        CoroutineScope(Dispatchers.IO).launch {
            runCatching {
                api(prefs.serverUrl).registerFcmToken(FcmTokenRequest(id, deviceToken, fcmToken))
            }
        }
    }

    private fun acknowledge(prefs: Prefs, orderId: String, result: String) {
        val id = prefs.deviceId ?: return
        val deviceToken = prefs.token ?: return
        CoroutineScope(Dispatchers.IO).launch {
            runCatching {
                val acknowledgementStatus = if (result.contains("FAILED") || result.contains("UNVERIFIED")) "FAILED" else "COMPLETED"
                api(prefs.serverUrl).acknowledgeOrder(
                    OrderAckRequest(id, deviceToken, orderId, acknowledgementStatus, result)
                )
            }
        }
    }

    private fun api(raw: String): CredixcelApi {
        val base = raw.trim().trimEnd('/')
        require(base.startsWith("https://", true))
        val json = Json { ignoreUnknownKeys = true }
        return Retrofit.Builder().baseUrl("$base/")
            .client(OkHttpClient.Builder().build())
            .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
            .build().create(CredixcelApi::class.java)
    }

    private fun hmacSha256(secret: String, value: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(secret.toByteArray(Charsets.UTF_8), "HmacSHA256"))
        return mac.doFinal(value.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
    }

    private fun constantTimeEquals(a: String, b: String): Boolean {
        if (a.length != b.length) return false
        var diff = 0
        for (i in a.indices) diff = diff or (a[i].code xor b[i].code)
        return diff == 0
    }
}
