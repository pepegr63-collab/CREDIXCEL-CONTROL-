package com.credixcel.control.data

import android.content.Context

class Prefs(context: Context) {
    private val p = context.getSharedPreferences(
        "credixcel",
        Context.MODE_PRIVATE
    )

    var deviceId: String?
        get() = p.getString("device_id", null)
        set(value) {
            p.edit().putString("device_id", value).apply()
        }

    var token: String?
        get() = p.getString("token", null)
        set(value) {
            p.edit().putString("token", value).apply()
        }

    var lastStatus: String
        get() = p.getString("last_status", "SIN ENROLAR") ?: "SIN ENROLAR"
        set(value) { p.edit().putString("last_status", value).apply() }

    var lastMessage: String
        get() = p.getString("last_message", "") ?: ""
        set(value) { p.edit().putString("last_message", value).apply() }

    var lastUpdatedAt: String
        get() = p.getString("last_updated_at", "—") ?: "—"
        set(value) { p.edit().putString("last_updated_at", value).apply() }

    var serverUrl: String
        get() = p.getString("server_url", "https://credixcel-control-server.onrender.com")!!
        set(value) {
            p.edit().putString("server_url", value.trimEnd('/')).apply()
        }
}
