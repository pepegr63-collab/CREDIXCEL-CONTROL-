
package com.credixcel.control

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.credixcel.control.data.Prefs
import com.credixcel.control.device.CredixcelDeviceAdminReceiver
import com.credixcel.control.device.DeviceActions
import com.credixcel.control.network.CredixcelApi
import com.credixcel.control.network.EnrollRequest
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json
import okhttp3.OkHttpClient
import okhttp3.MediaType.Companion.toMediaType
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import java.net.URL

private const val DEFAULT_SERVER =
    "https://credixcel-control-server.onrender.com"

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val prefs = Prefs(this)

        if (prefs.serverUrl.isBlank() ||
            prefs.serverUrl.contains("TU-DOMINIO")
        ) {
            prefs.serverUrl = DEFAULT_SERVER
        }

        setContent {
            App(prefs)
        }
    }

    @Composable
    private fun App(prefs: Prefs) {

        var server by remember {
            mutableStateOf(prefs.serverUrl)
        }

        var code by remember {
            mutableStateOf("")
        }

        var info by remember {
            mutableStateOf(
                if (prefs.deviceId != null && prefs.token != null)
                    "Dispositivo enrolado. Pulsa sincronizar para consultar el estado."
                else
                    "Equipo no enrolado"
            )
        }

        var deviceId by remember {
            mutableStateOf(prefs.deviceId)
        }

        var hasCredentials by remember {
            mutableStateOf(
                !prefs.deviceId.isNullOrBlank() &&
                !prefs.token.isNullOrBlank()
            )
        }

        var busy by remember {
            mutableStateOf(false)
        }

        var lastStatus by remember {
            mutableStateOf("Sin consultar")
        }

        var contractStatus by remember {
            mutableStateOf("Sin consultar")
        }

        var serverMessage by remember {
            mutableStateOf("")
        }

        var showAdminDialog by remember {
            mutableStateOf(false)
        }

        var adminStatus by remember {
            mutableStateOf("")
        }

        val scope = rememberCoroutineScope()

        val isOwner = DeviceActions.isDeviceOwner(this@MainActivity)

        MaterialTheme {

            Surface(Modifier.fillMaxSize()) {

                Column(
                    Modifier
                        .fillMaxSize()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {

                    Text(
                        "CREDIXCEL Control",
                        style = MaterialTheme.typography.headlineMedium
                    )

                    Text(
                        "Administración autorizada de dispositivos financiados"
                    )

                    OutlinedTextField(
                        value = server,
                        onValueChange = {
                            server = it
                            prefs.serverUrl = it
                        },
                        label = { Text("Servidor API") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = code,
                        onValueChange = {
                            code = it.uppercase().trim()
                        },
                        label = { Text("Código de enrolamiento") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Text("Estado del dispositivo: $lastStatus")
                    Text("Estado del contrato: $contractStatus")

                    if (serverMessage.isNotBlank()) {
                        Text("Mensaje: $serverMessage")
                    }

                    Text(
                        "Dispositivo enrolado: ${
                            if (hasCredentials) "Sí" else "No"
                        }"
                    )

                    Text(
                        "Device Owner: ${
                            if (isOwner) "Sí" else "No"
                        }"
                    )

                    // CONSULTAR AUTORIZACION DEL ADMINISTRADOR
                    Button(
                        enabled = !busy,
                        onClick = {

                            val owner =
                                DeviceActions.isDeviceOwner(this@MainActivity)

                            val admin =
                                DeviceActions.isAdmin(this@MainActivity)

                            adminStatus = buildString {

                                appendLine(
                                    "Device Owner: ${
                                        if (owner) "ACTIVO" else "NO ACTIVO"
                                    }"
                                )

                                appendLine(
                                    "Administrador: ${
                                        if (admin) "ACTIVO" else "NO ACTIVO"
                                    }"
                                )

                                append(
                                    if (owner) {
                                        "CREDIXCEL tiene autorización de propietario del dispositivo."
                                    } else {
                                        "CREDIXCEL no tiene autorización de propietario del dispositivo."
                                    }
                                )
                            }

                            showAdminDialog = true
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Ver autorización de administrador")
                    }

                    // VENTANA INFORMATIVA
                    if (showAdminDialog) {

                        AlertDialog(
                            onDismissRequest = {
                                showAdminDialog = false
                            },
                            title = {
                                Text("Autorización de administrador")
                            },
                            text = {
                                Text(adminStatus)
                            },
                            confirmButton = {
                                TextButton(
                                    onClick = {
                                        showAdminDialog = false
                                    }
                                ) {
                                    Text("Aceptar")
                                }
                            }
                        )
                    }

                    // ENROLAMIENTO
                    Button(
                        enabled = !busy && code.isNotBlank(),
                        onClick = {

                            scope.launch {

                                busy = true

                                try {

                                    val api = buildApi(server)

                                    val response = api.enroll(
                                        EnrollRequest(
                                            code.trim(),
                                            "${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}",
                                            Settings.Secure.getString(
                                                contentResolver,
                                                Settings.Secure.ANDROID_ID
                                            ) ?: "unknown"
                                        )
                                    )

                                    prefs.deviceId = response.deviceId
                                    prefs.token = response.deviceToken

                                    deviceId = response.deviceId
                                    hasCredentials = true

                                    lastStatus = response.status
                                    contractStatus = "Consultar al sincronizar"
                                    serverMessage = response.message

                                    info =
                                        "Enrolamiento completado. Ya puedes sincronizar el estado del panel."

                                } catch (e: Exception) {

                                    info =
                                        "Error de enrolamiento: ${
                                            e.localizedMessage ?: e.javaClass.simpleName
                                        }"

                                } finally {
                                    busy = false
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            if (busy) "Conectando…" else "Enrolar dispositivo"
                        )
                    }

                    // SINCRONIZACION
                    OutlinedButton(
                        enabled = hasCredentials && !busy,
                        onClick = {

                            scope.launch {

                                busy = true

                                try {

                                    val id =
                                        deviceId
                                            ?: prefs.deviceId
                                            ?: error("No hay ID de dispositivo guardado")

                                    val token =
                                        prefs.token
                                            ?: error("No hay credencial guardada; vuelve a enrolar")

                                    val state = buildApi(server).sync(
                                        mapOf(
                                            "deviceId" to id,
                                            "deviceToken" to token
                                        )
                                    )

                                    lastStatus = state.status
                                    contractStatus = state.contractStatus
                                    serverMessage = state.message.orEmpty()

                                    // Ejecuta el bloqueo de pantalla solo tras una respuesta
                                    // autenticada del servidor y si el equipo sigue siendo Device Owner.
                                    // Android lockNow bloquea la pantalla; no crea un bloqueo persistente.
                                    info = when {
                                        state.status.equals("LOCKED", ignoreCase = true) &&
                                            state.contractStatus.equals("ACTIVE", ignoreCase = true) -> {
                                            if (DeviceActions.lock(this@MainActivity)) {
                                                "Orden LOCKED recibida y bloqueo de pantalla solicitado a Android."
                                            } else {
                                                "El servidor indicó LOCKED, pero CREDIXCEL no tiene autorización Device Owner para bloquear la pantalla."
                                            }
                                        }
                                        state.status.equals("LOCKED", ignoreCase = true) ->
                                            "El servidor indicó LOCKED, pero el contrato no está ACTIVE. No se ejecutó el bloqueo."
                                        else ->
                                            "Sincronización completada correctamente. No se solicitó bloqueo de pantalla."
                                    }

                                } catch (e: Exception) {

                                    info =
                                        "Error de sincronización: ${
                                            e.localizedMessage ?: e.javaClass.simpleName
                                        }"

                                } finally {
                                    busy = false
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            if (busy) "Sincronizando…"
                            else "Sincronizar estado del panel"
                        )
                    }

                    Text(
                        info,
                        style = MaterialTheme.typography.bodyMedium
                    )

                    Text(
                        "La sincronización consulta el estado del servidor. No aplica bloqueos ni restricciones automáticas. Device Owner requiere aprovisionamiento Android independiente.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }

    private fun buildApi(rawUrl: String): CredixcelApi {

        val normalized = rawUrl.trim().trimEnd('/')

        require(
            normalized.startsWith("https://", ignoreCase = true)
        ) {
            "El servidor debe usar HTTPS"
        }

        val parsed = URL(normalized)

        require(parsed.host.isNotBlank()) {
            "La dirección del servidor no es válida"
        }

        val json = Json {
            ignoreUnknownKeys = true
        }

        return Retrofit.Builder()
            .baseUrl("$normalized/")
            .client(OkHttpClient.Builder().build())
            .addConverterFactory(
                json.asConverterFactory(
                    "application/json".toMediaType()
                )
            )
            .build()
            .create(CredixcelApi::class.java)
    }
}
