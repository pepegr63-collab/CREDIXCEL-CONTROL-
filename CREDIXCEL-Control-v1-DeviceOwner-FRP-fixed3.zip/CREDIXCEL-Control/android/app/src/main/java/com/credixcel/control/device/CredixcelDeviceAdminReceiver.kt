package com.credixcel.control.device

import android.app.admin.DeviceAdminReceiver

class CredixcelDeviceAdminReceiver : DeviceAdminReceiver()
