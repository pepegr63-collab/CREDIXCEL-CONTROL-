package com.credixcel.control.data

import android.content.Context

class Prefs(context: Context) {
    private val p = context.getSharedPreferences("credixcel", Context.MODE_PRIVATE)

    var deviceId: String?
        get() = p.getString("device_id", null)
        set(value) { p.edit().putString("device_id", value).apply() }

    var token: String?
        get() = p.getString("token", null)
        set(value) { p.edit().putString("token", value).apply() }

    var serverUrl: String
        get() = p.getString("server_url", "https://credixcel-control-server.onrender.com")
            ?: "https://credixcel-control-server.onrender.com"
        set(value) { p.edit().putString("server_url", value.trim().trimEnd('/')).apply() }

    /** Last server-authorized kiosk state; retained across process death and reboot. */
    var protectionActive: Boolean
        get() = p.getBoolean("protection_active", false)
        set(value) { p.edit().putBoolean("protection_active", value).commit() }

    var lastDeviceStatus: String?
        get() = p.getString("last_device_status", null)
        set(value) { p.edit().putString("last_device_status", value).apply() }

    var lastContractStatus: String?
        get() = p.getString("last_contract_status", null)
        set(value) { p.edit().putString("last_contract_status", value).apply() }
}
