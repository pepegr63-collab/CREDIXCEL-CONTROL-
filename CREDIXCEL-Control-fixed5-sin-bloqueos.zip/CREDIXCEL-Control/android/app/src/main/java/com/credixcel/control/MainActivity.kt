package com.credixcel.control

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.credixcel.control.data.Prefs
import com.credixcel.control.device.CredixcelDeviceAdminReceiver
import com.credixcel.control.device.DeviceActions
import com.credixcel.control.network.CredixcelApi
import com.credixcel.control.network.DeviceState
import com.credixcel.control.network.EnrollRequest
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App(Prefs(this)) }
    }

    @Composable
    private fun App(prefs: Prefs) {
        var server by remember { mutableStateOf(prefs.serverUrl) }
        var code by remember { mutableStateOf("") }
        var status by remember { mutableStateOf(prefs.lastStatus) }
        var message by remember { mutableStateOf(prefs.lastMessage.ifBlank { "Registra el equipo con el código proporcionado por el administrador." }) }
        var updatedAt by remember { mutableStateOf(prefs.lastUpdatedAt) }
        var busy by remember { mutableStateOf(false) }
        val scope = rememberCoroutineScope()
        val enrolled = prefs.deviceId != null && prefs.token != null
        val deviceOwner = DeviceActions.isDeviceOwner(this@MainActivity)

        MaterialTheme {
            Surface(Modifier.fillMaxSize()) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("CREDIXCEL Control", style = MaterialTheme.typography.headlineMedium)
                    Text("Administración transparente de dispositivos financiados")

                    OutlinedTextField(
                        value = server,
                        onValueChange = { server = it; prefs.serverUrl = it },
                        label = { Text("Servidor API") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (!enrolled) {
                        OutlinedTextField(
                            value = code,
                            onValueChange = { code = it },
                            label = { Text("Código de enrolamiento") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    Text("Estado del contrato: $status", style = MaterialTheme.typography.titleMedium)
                    Text("Mensaje del panel: $message")
                    Text("Última actualización: $updatedAt")
                    Text("Dispositivo enrolado: ${if (enrolled) "Sí" else "No"}")
                    Text("Device Owner: ${if (deviceOwner) "Sí" else "No"}")

                    Button(
                        onClick = {
                            startActivity(
                                Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                                    putExtra(
                                        DevicePolicyManager.EXTRA_DEVICE_ADMIN,
                                        ComponentName(this@MainActivity, CredixcelDeviceAdminReceiver::class.java)
                                    )
                                    putExtra(
                                        DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                                        "CREDIXCEL Control solicita permiso de administrador. Esto no convierte por sí solo la app en Device Owner."
                                    )
                                }
                            )
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Ver autorización de administrador") }

                    Button(
                        enabled = !busy && !enrolled && code.isNotBlank(),
                        onClick = {
                            scope.launch {
                                busy = true
                                try {
                                    val api = buildApi(server)
                                    val response = api.enroll(
                                        EnrollRequest(
                                            code.trim(),
                                            "${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}",
                                            Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown"
                                        )
                                    )
                                    prefs.deviceId = response.deviceId
                                    prefs.token = response.deviceToken
                                    status = response.status
                                    message = response.message
                                    updatedAt = "Enrolamiento completado"
                                    prefs.lastStatus = status
                                    prefs.lastMessage = message
                                    prefs.lastUpdatedAt = updatedAt
                                } catch (e: Exception) {
                                    message = "No se pudo enrolar: ${e.localizedMessage ?: e.javaClass.simpleName}"
                                } finally {
                                    busy = false
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(if (busy) "Conectando…" else "Enrolar dispositivo") }

                    OutlinedButton(
                        enabled = !busy && enrolled,
                        onClick = {
                            scope.launch {
                                busy = true
                                try {
                                    val api = buildApi(server)
                                    val response = api.sync(
                                        mapOf("deviceId" to prefs.deviceId!!, "deviceToken" to prefs.token!!)
                                    )
                                    showState(response) { newStatus, newMessage, newUpdatedAt ->
                                        status = newStatus
                                        message = newMessage
                                        updatedAt = newUpdatedAt
                                        prefs.lastStatus = newStatus
                                        prefs.lastMessage = newMessage
                                        prefs.lastUpdatedAt = newUpdatedAt
                                    }
                                } catch (e: Exception) {
                                    message = "Error de sincronización: ${e.localizedMessage ?: e.javaClass.simpleName}"
                                } finally {
                                    busy = false
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(if (busy) "Sincronizando…" else "Sincronizar estado del panel") }

                    Text(
                        "Importante: el estado recibido se muestra en esta app. No se bloquea el teléfono ni se impide restablecerlo o desinstalar la app por marcar un pago como pendiente. La autorización de administrador normal no equivale a Device Owner.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }

    private fun showState(
        state: DeviceState,
        update: (String, String, String) -> Unit
    ) {
        update(
            state.status,
            state.message?.takeIf { it.isNotBlank() } ?: "El panel no envió un mensaje adicional.",
            state.updatedAt ?: "Actualizado ahora"
        )
    }

    private fun buildApi(url: String): CredixcelApi {
        val cleanUrl = url.trim().trimEnd('/')
        require(cleanUrl.startsWith("https://", ignoreCase = true)) {
            "La dirección del servidor debe comenzar con https://"
        }
        val json = Json { ignoreUnknownKeys = true }
        return Retrofit.Builder()
            .baseUrl("$cleanUrl/")
            .client(OkHttpClient.Builder().build())
            .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
            .build()
            .create(CredixcelApi::class.java)
    }
}
